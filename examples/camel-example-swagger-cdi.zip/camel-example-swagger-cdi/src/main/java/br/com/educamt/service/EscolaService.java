package br.com.educamt.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

import javax.inject.Named;

import br.com.educamt.model.Escola;

@Named("escolaService")
public class EscolaService {

	public List<Escola> listarEscolasPorProfessor(Integer idProfessor){
		
		try {
		
			Class.forName("org.postgresql.Driver");
			Connection connection = null;
			connection = DriverManager.getConnection("jdbc:postgresql://govhack.cpghth3efxd9.sa-east-1.rds.amazonaws.com:5432/govhack","govhack", "govhackmt10");
			
			String selectTableSQL = "SELECT * from ";
		
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}
}