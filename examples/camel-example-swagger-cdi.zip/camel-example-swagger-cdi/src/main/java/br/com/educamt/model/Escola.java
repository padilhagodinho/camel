package br.com.educamt.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "Representa uma escola")
public class Escola {

	private String nome;

	@ApiModelProperty(value = "O nome da escola", required = true)
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
}
