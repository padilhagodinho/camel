package br.com.educamt.model;

public class Professor {

}
